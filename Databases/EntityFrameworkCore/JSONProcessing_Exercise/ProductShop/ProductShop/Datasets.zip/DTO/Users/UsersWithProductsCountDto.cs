﻿using Newtonsoft.Json;
using ProductShop.DTO.Products;
using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.DTO.Users
{
    public class UsersWithProductsCountDto
    {
        [JsonProperty("firstName")]
        public string FirstName { get; set; }

        [JsonProperty("lastName")]
        public string LastName { get; set; }

        [JsonProperty("age")]
        public int? Age { get; set; }

        [JsonProperty("soldProducts")]
        public SoldProductsDto SoldProducts { get; set; }
    }
}
