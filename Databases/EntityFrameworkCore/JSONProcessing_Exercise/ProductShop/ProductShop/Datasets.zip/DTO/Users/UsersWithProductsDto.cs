﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.DTO.Users
{
    public class UsersWithProductsDto
    {
    }
}
