﻿namespace MusicHub
{
    using System;
    using System.Globalization;
    using System.Linq;
    using System.Text;
    using Data;
    using Initializer;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            MusicHubDbContext context = 
                new MusicHubDbContext();

            //DbInitializer.ResetDatabase(context);

            Console.WriteLine(ExportSongsAboveDuration(context, 9));
        }

        public static string ExportAlbumsInfo(MusicHubDbContext context, int producerId)
        {
            var albums = context.Albums.Where(album => album.ProducerId.Equals(producerId))
               .Select(a => new
               {
                   a.Name,
                   ReleaseDate = a.ReleaseDate
                       .ToString("MM/dd/yyyy", CultureInfo.InvariantCulture),
                   ProducerName = a.Producer.Name,
                   Songs = a.Songs
                   .Select(song => new
                   {
                       song.Name,
                       songPrice = song.Price,
                       SongWritersName = song.Writer.Name,
                   })
                   .OrderByDescending(song => song.Name)
                   .ThenBy(song => song.SongWritersName)
                   .ToList(),
                   albumTotalPrice = a.Songs
                       .Sum(song => song.Price)
               })
               .OrderByDescending(album => album.albumTotalPrice)
               .ToList();

            var sb = new StringBuilder();

            foreach (var album in albums)
            {
                sb.AppendLine($"-AlbumName: {album.Name}");
                sb.AppendLine($"-ReleaseDate: {album.ReleaseDate}");
                sb.AppendLine($"-ProducerName: {album.ProducerName}");
                sb.AppendLine($"-Songs:");
                int counter = 1;
                foreach (var song in album.Songs)
                {
                    sb.AppendLine($"---#{counter}");
                    sb.AppendLine($"---SongName: {song.Name}"); ;
                    sb.AppendLine($"---Price: {song.songPrice:F2}");
                    sb.AppendLine($"---Writer: {song.SongWritersName}");
                    counter++;
                }
                sb.AppendLine($"-AlbumPrice: {(decimal)album.albumTotalPrice:F2}");
            }
            return sb.ToString().TrimEnd();
        }

        public static string ExportSongsAboveDuration(MusicHubDbContext context, int duration)
        {
            var songs = context.Songs
                .ToList()
                .Where(s => s.Duration.TotalSeconds > duration)
                .Select(s => new
                {
                    SongName = s.Name,
                    Writer = s.Writer.Name,
                    Performer = $"{s.SongPerformers.Select(sp => sp.Performer.FirstName).FirstOrDefault()}" +
                    $" {s.SongPerformers.Select(sp => sp.Performer.LastName).FirstOrDefault()}".TrimEnd(),
                    AlbumProducer = s.Album.Producer.Name,
                    Duration = s.Duration
                })
                .OrderBy(s => s.SongName)
                .ThenBy(s => s.Writer)
                .ThenBy(s => s.Performer)
                .ToList();

            StringBuilder sb = new StringBuilder();

            int row = 1;

            foreach (var song in songs)
            {
                sb.AppendLine($"-Song #{row}")
                    .AppendLine($"---SongName: {song.SongName}")
                    .AppendLine($"---Writer: {song.Writer}")
                    .AppendLine($"---Performer: {song.Performer}")
                    .AppendLine($"---AlbumProducer: {song.AlbumProducer}")
                    .AppendLine($"---Duration: {song.Duration}");

                row++;
            }

            return sb.ToString().TrimEnd();
        }
    }
}
