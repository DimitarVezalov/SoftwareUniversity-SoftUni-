﻿using System;

namespace CustomStack
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
