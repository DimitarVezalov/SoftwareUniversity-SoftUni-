﻿using System;

namespace CustomRandomList
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            RandomList randList = new RandomList();
            randList.Add("Pesho");
            randList.Add("Gosho");
            randList.Add("Misho");
            randList.Add("Tisho");
            randList.Add("Stoio");

            Console.WriteLine(randList.RandomString());
        }
    }
}
